/* $This file is distributed under the terms of the license in LICENSE$ */

package edu.cornell.mannlib.vitro.webapp.auth.rules;

public enum RuleDecision {
    ALLOW,
    DENY
}
