/* $This file is distributed under the terms of the license in LICENSE$ */

package edu.cornell.mannlib.vitro.webapp.audit;

import edu.cornell.mannlib.vitro.webapp.modules.Application;

/**
 * Module for the Audit engine
 */
public interface AuditModule extends Application.Module {
}
