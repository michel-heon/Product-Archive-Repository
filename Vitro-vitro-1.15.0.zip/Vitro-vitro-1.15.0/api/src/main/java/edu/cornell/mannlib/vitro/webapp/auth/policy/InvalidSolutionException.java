package edu.cornell.mannlib.vitro.webapp.auth.policy;

public class InvalidSolutionException extends RuntimeException {

    public InvalidSolutionException(String string) {
        super(string);
    }

}
