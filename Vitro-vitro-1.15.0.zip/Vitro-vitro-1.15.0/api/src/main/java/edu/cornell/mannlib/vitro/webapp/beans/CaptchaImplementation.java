package edu.cornell.mannlib.vitro.webapp.beans;

public enum CaptchaImplementation {
    RECAPTCHAV2,
    NANOCAPTCHA,
    NONE;
}
