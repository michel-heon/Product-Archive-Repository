/* $This file is distributed under the terms of the license in LICENSE$ */

package edu.cornell.mannlib.vitro.webapp.controller.edit;

import edu.cornell.mannlib.vedit.controller.BaseEditController;

/**
 * TODO
 */
public class FauxPropertyEditController extends BaseEditController {

}
