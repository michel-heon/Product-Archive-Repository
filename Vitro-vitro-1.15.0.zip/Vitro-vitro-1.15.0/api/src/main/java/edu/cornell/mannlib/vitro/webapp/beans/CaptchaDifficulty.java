package edu.cornell.mannlib.vitro.webapp.beans;

public enum CaptchaDifficulty {
    EASY,
    HARD
}
