/* $This file is distributed under the terms of the license in LICENSE$ */

package edu.cornell.mannlib.vitro.webapp.dao.jena;

public interface DatasetWrapperFactory {

    public DatasetWrapper getDatasetWrapper();

}
