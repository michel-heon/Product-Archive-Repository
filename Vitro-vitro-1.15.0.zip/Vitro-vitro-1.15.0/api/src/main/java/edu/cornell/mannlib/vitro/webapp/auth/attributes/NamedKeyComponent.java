package edu.cornell.mannlib.vitro.webapp.auth.attributes;

public enum NamedKeyComponent {
    SUPPRESSION_BY_URI,
    SUPPRESSION_BY_TYPE,
    NOT_RELATED,
}
