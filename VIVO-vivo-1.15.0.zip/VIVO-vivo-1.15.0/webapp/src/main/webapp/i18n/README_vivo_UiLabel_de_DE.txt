Please note that although usage of property files for translation of UI labels is supported at the moment,
it is deprecated and not recommended. Please, consider using ontology instead of property file located at:
Source code: [VIVO project]VIVO/home/src/main/resources/rdf/i18n/de_DE/interface-i18n/firsttime/vivo_UiLabel_de_DE.ttl
Deployment: [VIVO home]/rdf/i18n/de_DE/display/interface-i18n/vivo_UiLabel_de_DE.ttl

However, if you decide to use property files, please create and post the file in the same
directory as this Readme file.

